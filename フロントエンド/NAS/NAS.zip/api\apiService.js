import AsyncStorage from '@react-native-async-storage/async-storage';

const API_BASE_URL = 'https://soma-planning-promotional-moss.trycloudflare.com/api'; 

// ==========================================================
// トークン管理
// ==========================================================
export const storeTokens = async (accessToken, refreshToken) => {
  try {
    await AsyncStorage.setItem('accessToken', accessToken);
    await AsyncStorage.setItem('refreshToken', refreshToken);
  } catch (error) {
    console.error('Token storage error:', error);
  }
};

export const getAccessToken = async () => {
  try {
    return await AsyncStorage.getItem('accessToken');
  } catch (error) {
    console.error('Token retrieval error:', error);
    return null;
  }
};

export const getRefreshToken = async () => {
  try {
    return await AsyncStorage.getItem('refreshToken');
  } catch (error) {
    console.error('Token retrieval error:', error);
    return null;
  }
};

export const clearTokens = async () => {
  try {
    await AsyncStorage.removeItem('accessToken');
    await AsyncStorage.removeItem('refreshToken');
  } catch (error) {
    console.error('Token clear error:', error);
  }
};

export const refreshAccessToken = async () => {
  try {
    const refreshToken = await getRefreshToken();
    if (!refreshToken) {
      throw new Error('No refresh token available');
    }

    const response = await fetch(`${API_BASE_URL}/auth/token/refresh/`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ refresh: refreshToken }),
    });

    if (!response.ok) {
      throw new Error('Token refresh failed');
    }

    const data = await response.json();
    await AsyncStorage.setItem('accessToken', data.access);
    return data.access;
  } catch (error) {
    console.error('Token refresh error:', error);
    await clearTokens();
    throw error;
  }
};

// ==========================================================
// API呼び出しヘルパー
// ==========================================================
export const apiCall = async (endpoint, method = 'GET', body, requiresAuth = true) => {
  try {
    const headers = {
      'Content-Type': 'application/json',
    };

    if (requiresAuth) {
      const token = await getAccessToken();
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
    }

    const config = {
      method,
      headers,
    };

    if (body && method !== 'GET') {
      config.body = JSON.stringify(body);
    }

    const fullURL = `${API_BASE_URL}${endpoint}`;

    let response = await fetch(fullURL, config);
    const responseText = await response.text();

    if (responseText.trim().startsWith('<')) {
      throw new Error('サーバーがHTMLを返しました');
    }

    const data = JSON.parse(responseText);

    if (response.status === 401 && requiresAuth) {
      const newToken = await refreshAccessToken();
      if (newToken) {
        headers['Authorization'] = `Bearer ${newToken}`;
        config.headers = headers;
        response = await fetch(fullURL, config);
        const newResponseText = await response.text();
        const newData = JSON.parse(newResponseText);
        
        if (!response.ok) {
          throw new Error(newData.error || newData.message || 'API request failed');
        }
        
        return newData;
      }
    }

    if (!response.ok) {
      throw new Error(data.error || data.message || 'API request failed');
    }

    return data;
  } catch (error) {
    console.error('API呼び出しエラー:', error);
    throw error;
  }
};

// ==========================================================
// 認証API
// ==========================================================
export const login = async (email, password) => {
  const data = await apiCall('/auth/login/', 'POST', { email, password }, false);
  if (data.tokens) {
    await storeTokens(data.tokens.access, data.tokens.refresh);
  }
  return data;
};

export const register = async (userData) => {
  const data = await apiCall('/auth/register/', 'POST', userData, false);
  if (data.tokens) {
    await storeTokens(data.tokens.access, data.tokens.refresh);
  }
  return data;
};

export const logout = async () => {
  const refreshToken = await getRefreshToken();
  try {
    await apiCall('/auth/logout/', 'POST', { refresh: refreshToken });
  } catch (error) {
    console.error('Logout error:', error);
  } finally {
    await clearTokens(); 
  }
};

export const getUserInfo = async () => {
  return await apiCall('/auth/me/', 'GET');
};

export const updateUserInfo = async (userData) => {
  return await apiCall('/auth/me/', 'PATCH', userData);
};

export const changePassword = async (oldPassword, newPassword, newPasswordConfirm) => {
  return await apiCall('/auth/password/change/', 'POST', {
    old_password: oldPassword,
    new_password: newPassword,
    new_password_confirm: newPasswordConfirm,
  });
};

// Health API以降は省略（そのまま残してください）


// ==========================================================
// Health API
// ==========================================================
export const getHealthSummary = async () => {
  return await apiCall('/health/summary/', 'GET');
};

export const getHealthData = async () => {
  return await apiCall('/health/data/', 'GET');
};

export const addHealthData = async (measured_at, body, heart_rate) => {
  return await apiCall('/health/data/', 'POST', {
    measured_at,
    body,
    heart_rate,
  });
};

export const getSleepData = async () => {
  return await apiCall('/health/sleep/', 'GET');
};

export const addSleepData = async (date, sleep_hours) => {
  return await apiCall('/health/sleep/', 'POST', {
    date,
    sleep_hours,
  });
};

export const getWeeklyHealthData = async (weeksAgo = 0) => {
  return await apiCall(`/health/weekly/body/?weeks_ago=${weeksAgo}`, 'GET');
};

export const getWeeklySleepData = async (weeksAgo = 0) => {
  return await apiCall(`/health/weekly/sleep/?weeks_ago=${weeksAgo}`, 'GET');
};

// ==========================================================
// Helpdesk API
// ==========================================================
export const getHelpArticles = async () => {
  return await apiCall('/helpdesk/help/articles/', 'GET', null, false);
};

export const getHelpArticle = async (helpId) => {
  return await apiCall(`/helpdesk/help/articles/${helpId}/`, 'GET', null, false);
};

export const searchHelpArticles = async (query) => {
  return await apiCall(`/helpdesk/help/search/?q=${encodeURIComponent(query)}`, 'GET', null, false);
};

export const getInquiries = async () => {
  return await apiCall('/helpdesk/inquiries/', 'GET');
};

export const createInquiry = async (inquiryName, initialMessage) => {
  return await apiCall('/helpdesk/inquiries/new/', 'POST', {
    inquiry_name: inquiryName,
    initial_message: initialMessage,
  });
};

export const getInquiryDetail = async (inquiryId) => {
  return await apiCall(`/helpdesk/inquiries/${inquiryId}/`, 'GET');
};

export const addInquiryMessage = async (inquiryId, message) => {
  return await apiCall(`/helpdesk/inquiries/${inquiryId}/message/`, 'POST', {
    message,
  });
};

export const closeInquiry = async (inquiryId) => {
  return await apiCall(`/helpdesk/inquiries/${inquiryId}/close/`, 'POST');
};

export const sendChatbotMessage = async (message) => {
  return await apiCall('/helpdesk/chatbot/', 'POST', { message });
};

console.log('✅ apiService.js の全関数をエクスポートしました');