import { Picker } from '@react-native-picker/picker';
import React, { useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ScrollView,
  StyleSheet,
  Text,
  View
} from 'react-native';
import { LineChart } from 'react-native-chart-kit';

// ★変更点1：config.tsをやめて、最強のapiServiceを使う
// @ts-ignore
import { getWeeklyHealthData } from '../../api/apiService';

// 画面幅とグラフ幅の計算
const { width } = Dimensions.get('window');
const CHART_WIDTH = Math.min(width * 0.9, 400);

// --- データの型定義 ---
type DataEntry = {
  label: string;
  labels: string[];
  tempData: number[];
  hrData: number[];
};

// --- 初期データ構造 ---
const initialDataStructure: Record<string, DataEntry> = {
  thisWeek: { label: "今週", labels: ['日', '月', '火', '水', '木', '金', '土'], tempData: [], hrData: [] },
  oneWeekAgo: { label: "一週間前", labels: ['日', '月', '火', '水', '木', '金', '土'], tempData: [], hrData: [] },
  twoWeeksAgo: { label: "二週間前", labels: ['日', '月', '火', '水', '木', '金', '土'], tempData: [], hrData: [] },
  threeWeeksAgo: { label: "三週間前", labels: ['日', '月', '火', '水', '木', '金', '土'], tempData: [], hrData: [] },
  fourWeeksAgo: { label: "四週間前", labels: ['1週目', '2週目', '3週目', '4週目'], tempData: [], hrData: [] },
};

type DataPeriod = keyof typeof initialDataStructure;

export default function HeartRateScreen() {
  const [dataPeriod, setDataPeriod] = useState<DataPeriod>('thisWeek');
  
  // 画面に表示するデータ
  const [displayData, setDisplayData] = useState<DataEntry>(initialDataStructure['thisWeek']);
  const [isLoading, setIsLoading] = useState(false);

  // ★変更点2：新しいAPIを使ってデータを取得する
  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      
      const preset = initialDataStructure[dataPeriod];
      
      try {
        // 文字列キー('thisWeek'など)を、APIが求める数字(0, 1, 2...)に変換
        const weeksMap: Record<string, number> = {
            'thisWeek': 0,
            'oneWeekAgo': 1,
            'twoWeeksAgo': 2,
            'threeWeeksAgo': 3,
            'fourWeeksAgo': 4,
        };
        const weeksAgo = weeksMap[dataPeriod] || 0;

        // ★ここでapiServiceの関数を呼び出す（URLを書かなくていいので楽！）
        const apiData = await getWeeklyHealthData(weeksAgo);
        
        // サーバーからデータが返ってきたらセット
        setDisplayData({
          label: preset.label,
          labels: apiData.labels || preset.labels,
          tempData: apiData.tempData || [], // Django側がこの名前で返してくると想定
          hrData: apiData.hrData || []      // 同上
        });

      } catch (error) {
        console.error("通信エラー:", error);
        setDisplayData(preset);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [dataPeriod]);

  // 平均値の計算
  const calculateAverage = (data: number[]) => {
    if (!data || data.length === 0) return 0;
    const sum = data.reduce((a, b) => a + b, 0);
    return sum / data.length;
  };

  const avgTemp = useMemo(() => calculateAverage(displayData.tempData), [displayData]);
  const avgHr = useMemo(() => calculateAverage(displayData.hrData), [displayData]);

  // グラフ用データ作成
  const chartData = useMemo(() => ({
    labels: displayData.labels,
    datasets: [
      {
        data: displayData.tempData.length > 0 ? displayData.tempData : [0],
        name: '体温',
        color: (opacity = 1) => `rgba(75, 120, 255, ${opacity})`,
      },
      {
        data: displayData.hrData.length > 0 ? displayData.hrData : [0],
        name: '心拍',
        color: (opacity = 1) => `rgba(255, 130, 0, ${opacity})`,
      },
      // Y軸の範囲固定用ダミー
      {
        data: [35.5, 38.0, 60, 80],
        color: () => 'rgba(0, 0, 0, 0)',
        withDots: false,
        withLines: false,
        legendFontColor: 'rgba(0, 0, 0, 0)'
      }
    ],
  }), [displayData]);

  const hasData = displayData.tempData.length > 0 || displayData.hrData.length > 0;

  const NoDataMessage = () => (
    <View style={styles.noDataContainer}>
      <Text style={styles.noDataText}>表示するデータがありません</Text>
    </View>
  );

  return (
    <ScrollView contentContainerStyle={styles.container}>
      
      <View style={styles.messageBox}>
        <Text style={styles.messageTextCenter}>
          {hasData ? "測定データが表示されています。" : "データがありません。測定してください。"}
        </Text>
      </View>

      <View style={styles.periodSelectorContainer}>
        <Text style={styles.periodLabel}>{displayData.label}</Text>
        <View style={styles.pickerWrapper}>
          <Picker
            selectedValue={dataPeriod}
            onValueChange={(itemValue) => setDataPeriod(itemValue as DataPeriod)}
            style={styles.periodSelect}
            itemStyle={styles.pickerItem}
            enabled={!isLoading}
          >
            {Object.keys(initialDataStructure).map(key => (
              <Picker.Item 
                key={key} 
                label={initialDataStructure[key as DataPeriod].label} 
                value={key} 
              />
            ))}
          </Picker>
        </View>
      </View>

      <View style={styles.chartArea}>
        <Text style={styles.graphTitle}>心拍・体温</Text>
        
        {isLoading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color="#4a90e2" />
            <Text style={{marginTop: 10, color: '#777'}}>データ読み込み中...</Text>
          </View>
        ) : hasData ? (
          <LineChart
            data={chartData}
            width={CHART_WIDTH - 40}
            height={200}
            yAxisSuffix=""
            yAxisInterval={1}
            chartConfig={{
              backgroundColor: '#ffffff',
              backgroundGradientFrom: '#ffffff',
              backgroundGradientTo: '#ffffff',
              decimalPlaces: 1,
              color: (opacity = 1) => `rgba(0, 0, 0, ${opacity * 0.7})`,
              labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity * 0.7})`,
              propsForDots: { r: '4', strokeWidth: '2' },
              propsForLabels: { fontSize: 10 },
            }}
            style={styles.chartStyle}
          />
        ) : (
          <NoDataMessage />
        )}
      </View>

      <View style={styles.legendContainer}>
        <View style={styles.legendItem}>
          <View style={[styles.legendColor, { backgroundColor: 'rgba(75, 120, 255, 1)' }]} />
          <Text style={styles.legendText}>体温</Text>
        </View>
        <View style={styles.legendItem}>
          <View style={[styles.legendColor, { backgroundColor: 'rgba(255, 130, 0, 1)' }]} />
          <Text style={styles.legendText}>心拍</Text>
        </View>
      </View>

      <View style={styles.averageSummary}>
        <Text style={styles.averageText}>週平均体温: {avgTemp.toFixed(1)}度</Text>
        <Text style={styles.averageText}>週平均心拍数: {Math.round(avgHr)}回/分</Text>
      </View>
      
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    alignItems: 'center',
    padding: 10,
    paddingTop: 0,
    backgroundColor: '#FEF1E7',
    maxWidth: 420,
    alignSelf: 'center',
  },
  messageBox: {
    width: '100%',
    backgroundColor: '#fff',
    borderRadius: 8,
    paddingVertical: 15,
    paddingHorizontal: 15,
    marginBottom: 20,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#ddd',
  },
  messageTextCenter: {
    fontSize: 15,
    color: '#333',
    fontWeight: 'normal',
  },
  periodSelectorContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '100%',
    marginBottom: 20,
    paddingHorizontal: 10,
  },
  periodLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  pickerWrapper: {
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 4,
    height: 40,
    width: 140,
    justifyContent: 'center',
    overflow: 'hidden',
    backgroundColor: 'white',
  },
  periodSelect: {
    width: '100%',
    height: 40,
  },
  pickerItem: {
    fontSize: 14,
  },
  chartArea: {
    width: '100%',
    backgroundColor: 'white',
    borderWidth: 2,
    borderColor: '#757575',
    borderRadius: 6,
    padding: 20,
    marginBottom: 0,
    alignItems: 'center',
    position: 'relative',
    minHeight: 280,
  },
  graphTitle: {
    textAlign: 'center',
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 15,
    color: '#333',
  },
  chartStyle: {
    borderRadius: 0,
    marginRight: 10,
  },
  noDataContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    height: 200,
    padding: 20,
    width: CHART_WIDTH - 40,
  },
  loadingContainer: {
    height: 200,
    justifyContent: 'center',
    alignItems: 'center',
  },
  noDataText: {
    fontSize: 16,
    color: '#777',
    textAlign: 'center',
  },
  legendContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 15,
    marginBottom: 20,
    width: '100%',
    gap: 30,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  legendColor: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 6,
  },
  legendText: {
    fontSize: 16,
    color: '#333',
  },
  averageSummary: {
    width: '100%',
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: 15,
    marginBottom: 20,
  },
  averageText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
});