import { Picker } from '@react-native-picker/picker';
import React, { useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ScrollView,
  StyleSheet,
  Text,
  View
} from 'react-native';
import { BarChart } from 'react-native-chart-kit';

// ★変更点1：新しいAPIサービスを使う
// @ts-ignore
import { getWeeklySleepData } from '../../api/apiService';

const { width } = Dimensions.get('window');
const CHART_WIDTH = Math.min(width * 0.9, 400);

// --- データ型定義 ---
type SleepDataEntry = {
  label: string;
  labels: string[];
  data: number[];
};

// --- 初期データ ---
const initialSleepData: Record<string, SleepDataEntry> = {
  thisWeek: { label: "今週", labels: ['日', '月', '火', '水', '木', '金', '土'], data: [] },
  oneWeekAgo: { label: "一週間前", labels: ['日', '月', '火', '水', '木', '金', '土'], data: [] },
  twoWeeksAgo: { label: "二週間前", labels: ['日', '月', '火', '水', '木', '金', '土'], data: [] },
  threeWeeksAgo: { label: "三週間前", labels: ['日', '月', '火', '水', '木', '金', '土'], data: [] },
  fourWeeksAgo: { label: "四週間前", labels: ['1週目', '2週目', '3週目', '4週目'], data: [] },
};

type DataPeriod = keyof typeof initialSleepData;

export default function SleepChartScreen() {
  const [dataPeriod, setDataPeriod] = useState<DataPeriod>('thisWeek');
  const [displayData, setDisplayData] = useState<SleepDataEntry>(initialSleepData['thisWeek']);
  const [isLoading, setIsLoading] = useState(false);

  // ★変更点2：APIからデータを取得する処理
  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      const preset = initialSleepData[dataPeriod];

      try {
        // 文字列キーを数字に変換
        const weeksMap: Record<string, number> = {
            'thisWeek': 0,
            'oneWeekAgo': 1,
            'twoWeeksAgo': 2,
            'threeWeeksAgo': 3,
            'fourWeeksAgo': 4,
        };
        const weeksAgo = weeksMap[dataPeriod] || 0;

        // ★ここでapiServiceの関数を使う
        const apiData = await getWeeklySleepData(weeksAgo);
        
        setDisplayData({
          label: preset.label,
          labels: apiData.labels || preset.labels,
          data: apiData.data || [] // サーバーからは [7.5, 6.0...] のように時間が来る想定
        });

      } catch (error) {
        console.error("通信エラー:", error);
        setDisplayData(preset);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [dataPeriod]);

  // 平均睡眠時間の計算
  const averageSleep = useMemo(() => {
    if (displayData.data.length === 0) return '平均睡眠時間: --時間--分';
    
    const sum = displayData.data.reduce((a, b) => a + b, 0);
    const avgHours = sum / displayData.data.length;
    const hours = Math.floor(avgHours);
    const minutes = Math.round((avgHours - hours) * 60);

    return `平均睡眠時間: ${hours}時間${minutes}分`;
  }, [displayData]);

  // 応援メッセージ
  const [characterMessage, setCharacterMessage] = useState('');
  useEffect(() => {
    const messages = [
      '今日も一日お疲れ様です！',
      '適度な運動も睡眠には大切ですよ。',
      'ぐっすり眠れていますか？',
      '良い睡眠は健康の基本です。',
    ];
    const randomIndex = Math.floor(Math.random() * messages.length);
    setCharacterMessage(messages[randomIndex]);
  }, [dataPeriod]);

  const hasData = displayData.data.length > 0;

  return (
    <ScrollView contentContainerStyle={styles.container}>
      
      <View style={styles.messageBox}>
        <Text style={styles.messageTextCenter}>{characterMessage}</Text>
      </View>

      <View style={styles.periodSelectorContainer}>
        <Text style={styles.periodLabel}>{displayData.label}</Text>
        <View style={styles.pickerWrapper}>
          <Picker
            selectedValue={dataPeriod}
            onValueChange={(itemValue) => setDataPeriod(itemValue as DataPeriod)}
            style={styles.periodSelect}
            itemStyle={styles.pickerItem}
            enabled={!isLoading}
          >
            <Picker.Item label="今週" value="thisWeek" />
            <Picker.Item label="一週間前" value="oneWeekAgo" />
            <Picker.Item label="二週間前" value="twoWeeksAgo" />
            <Picker.Item label="三週間前" value="threeWeeksAgo" />
            <Picker.Item label="四週間前" value="fourWeeksAgo" />
          </Picker>
        </View>
      </View>

      <View style={styles.chartArea}>
        <Text style={styles.graphTitle}>睡眠時間</Text>
        
        {isLoading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color="#FF6699" />
            <Text style={{marginTop: 10, color: '#777'}}>読み込み中...</Text>
          </View>
        ) : hasData ? (
          <BarChart
            data={{
              labels: displayData.labels,
              datasets: [{ data: displayData.data }]
            }}
            width={CHART_WIDTH - 40}
            height={220}
            yAxisLabel=""
            yAxisSuffix="h"
            chartConfig={{
              backgroundColor: '#ffffff',
              backgroundGradientFrom: '#ffffff',
              backgroundGradientTo: '#ffffff',
              decimalPlaces: 1,
              color: (opacity = 1) => `rgba(255, 102, 153, ${opacity})`, 
              labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity * 0.7})`,
              barPercentage: 0.6,
            }}
            style={styles.chartStyle}
            showValuesOnTopOfBars={true}
          />
        ) : (
          <View style={styles.noDataContainer}>
            <Text style={styles.noDataText}>表示するデータがありません</Text>
          </View>
        )}
      </View>
      
      <Text style={styles.averageText}>{averageSleep}</Text>

    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    alignItems: 'center',
    padding: 10,
    paddingTop: 0,
    backgroundColor: '#FEF1E7',
    maxWidth: 420,
    alignSelf: 'center',
  },
  messageBox: {
    width: '100%',
    backgroundColor: '#fff',
    borderRadius: 8,
    paddingVertical: 15,
    paddingHorizontal: 15,
    marginBottom: 20,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#ddd',
  },
  messageTextCenter: { fontSize: 15, color: '#333' },
  periodSelectorContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '100%',
    marginBottom: 20,
    paddingHorizontal: 10,
  },
  periodLabel: { fontSize: 16, fontWeight: 'bold', color: '#333' },
  pickerWrapper: {
    borderColor: '#ccc', borderWidth: 1, borderRadius: 4,
    height: 40, width: 130, justifyContent: 'center', backgroundColor: 'white'
  },
  periodSelect: { width: '100%', height: 40 },
  pickerItem: { fontSize: 16 },
  chartArea: {
    width: '100%',
    backgroundColor: 'white',
    borderWidth: 2,
    borderColor: '#757575',
    borderRadius: 6,
    padding: 20,
    marginBottom: 20,
    alignItems: 'center',
    minHeight: 300,
  },
  graphTitle: {
    textAlign: 'center', fontSize: 22, fontWeight: 'bold',
    marginBottom: 15, color: '#333',
  },
  chartStyle: { borderRadius: 0, marginRight: 10 },
  noDataContainer: {
    alignItems: 'center', justifyContent: 'center',
    height: 200, width: CHART_WIDTH - 40,
  },
  loadingContainer: {
    height: 200, justifyContent: 'center', alignItems: 'center',
  },
  noDataText: { fontSize: 16, color: '#777' },
  averageText: {
    width: '100%', textAlign: 'center', fontSize: 20, fontWeight: 'bold',
    color: '#333', marginBottom: 20,
  },
});