import { useNavigation } from 'expo-router';
import React, { useEffect, useRef, useState } from 'react';
import {
    ActivityIndicator,
    Alert,
    Modal,
    SafeAreaView,
    ScrollView,
    StyleSheet,
    Text,
    TextInput,
    TouchableOpacity,
    View
} from 'react-native';

// ★変更点1：新しいAPIサービスを使う（魔法の言葉つき）
// @ts-ignore
import {
    addInquiryMessage,
    closeInquiry,
    createInquiry,
    getInquiries
} from '../../api/apiService';

// --- データ型定義 ---
type Sender = 'user' | 'admin' | 'system';
type Status = 'pending' | 'resolved' | 'unhandled';

interface Message {
  sender: Sender;
  text: string;
  resolution?: boolean;
}

interface Thread {
  id: string;
  title: string;
  date: string;
  status: Status;
  messages: Message[];
}

interface Threads {
  [key: string]: Thread;
}

const CONTACT_CATEGORIES = [
  "パスワードについて", "グラフについて", "利用者情報について", "その他"
];

// --- カスタムモーダルコンポーネント (TopicModal - 変更なし) ---
interface TopicModalProps {
  isVisible: boolean;
  onClose: () => void;
  onConfirm: (title: string) => void;
}

const TopicModal: React.FC<TopicModalProps> = ({ isVisible, onClose, onConfirm }) => {
  const [selectedCategory, setSelectedCategory] = useState(CONTACT_CATEGORIES[0]);
  const [isConfirming, setIsConfirming] = useState(false);

  useEffect(() => {
    if (!isVisible) {
      setIsConfirming(false);
      setSelectedCategory(CONTACT_CATEGORIES[0]);
    }
  }, [isVisible]);

  const handleSelectConfirm = () => {
    if (selectedCategory) {
      setIsConfirming(true);
    }
  };

  const handleFinalConfirm = () => {
    onConfirm(selectedCategory);
    onClose();
  };

  const handleRevert = () => {
    setIsConfirming(false);
  };

  const SelectionContent = (
    <>
      <Text style={modalStyles.title}>お問い合わせ項目を選択</Text>
      <View style={modalStyles.categoryContainer}>
        {CONTACT_CATEGORIES.map(category => (
          <TouchableOpacity
            key={category}
            style={[
              modalStyles.categoryItem,
              selectedCategory === category && modalStyles.categoryItemSelected
            ]}
            onPress={() => setSelectedCategory(category)}
          >
            <Text style={modalStyles.categoryText}>{category}</Text>
          </TouchableOpacity>
        ))}
      </View>
      <View style={modalStyles.buttons}>
        <TouchableOpacity
          style={[modalStyles.button, modalStyles.cancelBtn]}
          onPress={onClose}
        >
          <Text style={modalStyles.cancelText}>キャンセル</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[modalStyles.button, modalStyles.confirmBtn]}
          onPress={handleSelectConfirm}
          disabled={!selectedCategory}
        >
          <Text style={modalStyles.confirmText}>決定</Text>
        </TouchableOpacity>
      </View>
    </>
  );

  const ConfirmationContent = (
    <>
      <View style={modalStyles.confirmationArea}>
        <Text style={modalStyles.confirmationTitle}>
          {selectedCategory}
        </Text>
        <Text style={modalStyles.confirmationText}>
          決定すると変更できません。間違いはありませんか？
        </Text>
        <View style={[modalStyles.buttons, modalStyles.confirmationButtons]}>
          <TouchableOpacity
            style={[modalStyles.button, modalStyles.revertBtn]}
            onPress={handleRevert}
          >
            <Text style={modalStyles.revertText}>いいえ</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[modalStyles.button, modalStyles.finalConfirmBtn]}
            onPress={handleFinalConfirm}
          >
            <Text style={modalStyles.finalConfirmText}>はい</Text>
          </TouchableOpacity>
        </View>
      </View>
    </>
  );

  return (
    <Modal
      animationType="fade"
      transparent={true}
      visible={isVisible}
      onRequestClose={onClose}
    >
      <View style={modalStyles.overlay}>
        <View style={modalStyles.content}>
          {isConfirming ? ConfirmationContent : SelectionContent}
        </View>
      </View>
    </Modal>
  );
};

// --- サブコンポーネント: メッセージバブル (変更なし) ---
interface MessageBubbleProps {
  message: Message;
  threadId: string;
  threads: Threads;
  handleResolve: (threadId: string, resolved: boolean) => void;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ message, threadId, threads, handleResolve }) => {
  const isUser = message.sender === 'user';
  const isAdmin = message.sender === 'admin';
  const isSystem = message.sender === 'system';

  const showButtons = message.resolution && threads[threadId]?.status === 'pending';

  return (
    <View style={isSystem ? styles.systemMsgContainer : isUser ? styles.userMsgContainer : styles.adminMsgContainer}>
      <Text style={[
        styles.messageBubble,
        isSystem && styles.systemMsg,
        isAdmin && styles.adminMsg,
        isUser && styles.userMsg,
      ]}>
        {message.text}
      </Text>

      {showButtons && (
        <View style={styles.resolveButtons}>
          <Text style={{ fontSize: 13, color: '#777' }}>解決しましたか？</Text>
          <TouchableOpacity
            style={[styles.resolveBtn, styles.resolveBtnYes]}
            onPress={() => handleResolve(threadId, true)}
          >
            <Text style={styles.resolveBtnText}>はい</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.resolveBtn, styles.resolveBtnNo]}
            onPress={() => handleResolve(threadId, false)}
          >
            <Text style={styles.resolveBtnText}>いいえ</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
};

// --- メインコンポーネント ---
export default function ContactFormScreen() {
  const navigation = useNavigation();
  const [threads, setThreads] = useState<Threads>({}); 
  const [activeThreadId, setActiveThreadId] = useState<string | null>(null);
  const [messageInput, setMessageInput] = useState('');
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const chatScrollViewRef = useRef<ScrollView>(null);
  const isMounted = useRef(true);

  useEffect(() => {
    return () => {
      isMounted.current = false;
    };
  }, []);

  // ★変更点2：画面を開いた時にAPIから履歴を取得する
  useEffect(() => {
    const fetchThreads = async () => {
      setIsLoading(true);
      try {
        // APIサービスの関数を呼ぶだけ！
        const data = await getInquiries();
        
        // サーバーからのデータを整形してセット (サーバーが配列で返す場合を想定)
        // もしオブジェクトで返るなら setThreads(data) だけでOK
        if (Array.isArray(data)) {
            const threadsObj: Threads = {};
            data.forEach((t: Thread) => { threadsObj[t.id] = t; });
            setThreads(threadsObj);
        } else {
            setThreads(data || {});
        }

      } catch (error) {
        console.log("履歴の読み込みに失敗しました（初回は無視してOK）");
      } finally {
        setIsLoading(false);
      }
    };
    fetchThreads();
  }, []);

  useEffect(() => {
    if (chatScrollViewRef.current) {
      chatScrollViewRef.current.scrollToEnd({ animated: true });
    }
  }, [threads[activeThreadId as string]?.messages.length, activeThreadId]);

  const loadThread = (threadId: string) => {
    setActiveThreadId(threadId);
    setMessageInput('');
  };

  // ★変更点3：解決ボタンを押した時にAPIへ通知
  const handleResolve = async (threadId: string, resolved: boolean) => {
    const thread = threads[threadId];
    if (!thread) return;

    // 画面更新
    let systemMessageText = '';
    const newStatus: Status = resolved ? 'resolved' : 'unhandled';

    if (resolved) {
      systemMessageText = '「はい」が選択されました。このお問い合わせは「回答済み」になりました。';
    } else {
      systemMessageText = '「いいえ」が選択されました。引き続きご質問ください。';
    }

    const newThreads = { ...threads };
    newThreads[threadId] = {
      ...thread,
      status: newStatus,
      messages: [
        ...thread.messages.slice(0, -1),
        { sender: 'system', text: systemMessageText },
      ],
    };
    setThreads(newThreads);

    // API通信
    try {
      // 解決ならクローズAPIを呼ぶ（未解決の場合は特別な処理は不要だが、必要ならAPIを追加）
      if (resolved) {
          await closeInquiry(threadId);
      }
    } catch (error) {
      console.error("ステータス更新エラー:", error);
    }
  };

  const isSendDisabled = () => {
    const thread = threads[activeThreadId as string];
    if (!activeThreadId || !thread) return true;
    if (thread.status === 'pending') return true;
    return messageInput.trim() === '';
  };

  // ★変更点4：メッセージ送信時にAPIへ通信
  const handleSendMessage = async () => {
    const text = messageInput.trim();
    const threadId = activeThreadId as string;
    const thread = threads[threadId];

    if (isSendDisabled() || text === '') return;

    try {
      // APIサービスの関数を使用
      await addInquiryMessage(threadId, text);

      // 成功したら画面更新
      const newThreads = { ...threads };
      newThreads[threadId] = {
        ...thread,
        status: 'unhandled',
        messages: [...thread.messages, { sender: 'user', text: text }],
      };
      setThreads(newThreads);
      setMessageInput('');

    } catch (error) {
      Alert.alert("エラー", "送信に失敗しました");
    }
  };

  // ★変更点5：新規スレッド作成時にAPIへ通信
  const handleNewContactConfirm = async (newTitle: string) => {
    try {
      // APIサービスの関数を使用
      // createInquiry(件名, 初回メッセージ)
      // ※ここでは初回メッセージとして件名と同じものを送るか、空文字にする
      const newThreadData = await createInquiry(newTitle, "お問い合わせを開始します");

      // 画面に追加
      setThreads(prev => ({
        ...prev,
        [newThreadData.id]: newThreadData
      }));
      setActiveThreadId(newThreadData.id);
      setMessageInput('');
      Alert.alert("新規お問い合わせ", `「${newTitle}」の新規お問い合わせが開始されました。`);

    } catch (error) {
      Alert.alert("エラー", "作成に失敗しました");
    }
  };

  const sortedThreadKeys = Object.keys(threads).sort((a, b) => {
    return new Date(threads[b].date).getTime() - new Date(threads[a].date).getTime();
  });

  const activeThread = activeThreadId ? threads[activeThreadId] : null;

  return (
    <SafeAreaView style={styles.safeArea}>
      <TopicModal
        isVisible={isModalVisible}
        onClose={() => setIsModalVisible(false)}
        onConfirm={handleNewContactConfirm}
      />

      <View style={styles.topBar}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.backButtonText}>← 戻る</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>お問い合わせフォーム</Text>
      </View>

      <View style={styles.contentWrapper}>
        <TouchableOpacity
          style={styles.newContactBtn}
          onPress={() => setIsModalVisible(true)}
        >
          <Text style={styles.newContactText}>新規お問い合わせ</Text>
        </TouchableOpacity>

        <View style={styles.container}>
          {/* 履歴リスト */}
          {isLoading && Object.keys(threads).length === 0 ? (
            <View style={{ padding: 20 }}>
              <ActivityIndicator size="large" color="#4a90e2" />
              <Text style={{ textAlign: 'center', marginTop: 10, color: '#777' }}>読み込み中...</Text>
            </View>
          ) : (
            <ScrollView style={styles.historyList}>
              {sortedThreadKeys.map(key => (
                <HistoryItemComponent key={key} thread={threads[key]} loadThread={loadThread} activeThreadId={activeThreadId} />
              ))}
            </ScrollView>
          )}

          {/* チャットエリア */}
          <ScrollView
            ref={chatScrollViewRef}
            style={styles.chatArea}
            contentContainerStyle={styles.chatAreaContent}
          >
            {activeThread ? (
              activeThread.messages.map((msg, index) => (
                <MessageBubble
                  key={index}
                  message={msg}
                  threadId={activeThread.id}
                  threads={threads}
                  handleResolve={handleResolve}
                />
              ))
            ) : (
              <Text style={styles.initialMsg}>履歴を選択するか、新規お問い合わせを作成してください。</Text>
            )}
          </ScrollView>

          {/* 入力エリア */}
          <View style={styles.inputArea}>
            <TextInput
              style={styles.inputBox}
              placeholder="メッセージを入力..."
              value={messageInput}
              onChangeText={setMessageInput}
              editable={!!activeThread && activeThread.status !== 'pending'}
            />
            <TouchableOpacity
              style={[styles.sendBtn, isSendDisabled() && styles.sendBtnDisabled]}
              onPress={handleSendMessage}
              disabled={isSendDisabled()}
            >
              <Text style={styles.sendIcon}>▶</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
}

// --- サブコンポーネント: 履歴アイテム (変更なし) ---
interface HistoryItemProps {
  thread: Thread;
  loadThread: (id: string) => void;
  activeThreadId: string | null;
}

const HistoryItemComponent: React.FC<HistoryItemProps> = ({ thread, loadThread, activeThreadId }) => {
  const isSelected = thread.id === activeThreadId;
  const statusClass = thread.status === 'pending'
    ? styles.statusPending
    : thread.status === 'resolved'
      ? styles.statusResolved
      : styles.statusUnhandled;
  const statusText = thread.status === 'pending' ? '回答待ち' : thread.status === 'resolved' ? '回答済み' : '未対応';

  return (
    <TouchableOpacity
      style={[styles.historyItem, isSelected && styles.historyItemActive]}
      onPress={() => loadThread(thread.id)}
    >
      <Text style={styles.historyTitle}>{thread.title}</Text>
      <View style={styles.historyInfo}>
        <Text style={styles.historyDate}>{thread.date}</Text>
        <View style={[styles.statusBadge, statusClass]}>
          <Text style={styles.statusText}>{statusText}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );
};

// --- スタイルシート (変更なし) ---
const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#FEF1E7' },
  contentWrapper: { flex: 1, width: '100%', paddingHorizontal: 20, alignItems: 'center' },
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', width: '100%', paddingHorizontal: 20, paddingVertical: 10, backgroundColor: '#FEF1E7', borderBottomWidth: 0, minHeight: 50, position: 'relative' },
  backButton: { position: 'absolute', left: 20, backgroundColor: '#e0e0e0', borderWidth: 1, borderColor: '#ccc', paddingVertical: 5, paddingHorizontal: 10, borderRadius: 6 },
  backButtonText: { fontSize: 14, color: '#333', fontWeight: 'normal' },
  headerTitle: { textAlign: 'center', color: '#333', fontSize: 18, fontWeight: 'bold', marginTop: 0, marginBottom: 0 },
  newContactBtn: { width: '100%', padding: 12, marginBottom: 25, backgroundColor: '#f7f7f7', borderWidth: 1, borderColor: '#ccc', borderRadius: 6, alignItems: 'center' },
  newContactText: { fontSize: 16, fontWeight: 'bold', color: '#333' },
  container: { width: '100%', flex: 1, backgroundColor: '#fff', borderRadius: 8, borderWidth: 1, borderColor: '#ccc', overflow: 'hidden', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 5, elevation: 5 },
  historyList: { padding: 10, backgroundColor: '#f5f5f5', borderBottomWidth: 2, borderBottomColor: '#ccc', flexGrow: 0, maxHeight: 200 },
  historyItem: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: 'white', padding: 12, borderWidth: 1, borderColor: '#ddd', borderRadius: 6, marginBottom: 8 },
  historyItemActive: { borderColor: '#4a90e2', backgroundColor: '#e8f0ff' },
  historyTitle: { fontSize: 16, fontWeight: 'bold' },
  historyInfo: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  historyDate: { fontSize: 12, color: '#777' },
  statusBadge: { fontSize: 12, paddingVertical: 3, paddingHorizontal: 8, borderRadius: 12, fontWeight: 'bold' },
  statusText: { color: 'white', fontSize: 12, fontWeight: 'bold' },
  statusPending: { backgroundColor: '#dc3545' },
  statusResolved: { backgroundColor: '#28a745' },
  statusUnhandled: { backgroundColor: '#ffc107' },
  chatArea: { flexGrow: 1, padding: 20 },
  chatAreaContent: { gap: 15, justifyContent: 'flex-start' },
  initialMsg: { textAlign: 'center', fontSize: 13, color: '#777', width: '100%', marginTop: 'auto' },
  messageBubble: { paddingVertical: 10, paddingHorizontal: 15, borderRadius: 18, maxWidth: '100%', lineHeight: 20, overflow: 'hidden' },
  adminMsgContainer: { alignSelf: 'flex-start', maxWidth: '80%' },
  userMsgContainer: { alignSelf: 'flex-end', maxWidth: '80%' },
  systemMsgContainer: { alignSelf: 'center', width: '100%' },
  adminMsg: { backgroundColor: '#f0f0f0', borderBottomLeftRadius: 4 },
  userMsg: { backgroundColor: '#4a90e2', color: 'white', borderBottomRightRadius: 4 },
  systemMsg: { textAlign: 'center', fontSize: 13, color: '#777', width: '100%', backgroundColor: 'transparent', padding: 0 },
  resolveButtons: { flexDirection: 'row', gap: 10, marginTop: 10, alignItems: 'center' },
  resolveBtn: { borderWidth: 1, backgroundColor: 'white', paddingVertical: 5, paddingHorizontal: 15, borderRadius: 6 },
  resolveBtnText: { fontSize: 14 },
  resolveBtnYes: { borderColor: '#dc3545' },
  resolveBtnNo: { borderColor: '#007bff' },
  inputArea: { flexDirection: 'row', padding: 15, borderTopWidth: 1, borderTopColor: '#ddd', backgroundColor: '#f9f9f9', flexShrink: 0 },
  inputBox: { flexGrow: 1, paddingVertical: 10, paddingHorizontal: 15, fontSize: 16, borderWidth: 1, borderColor: '#ccc', borderRadius: 20, marginRight: 10, backgroundColor: 'white', height: 40 },
  sendBtn: { backgroundColor: '#4a90e2', borderRadius: 50, width: 45, height: 45, justifyContent: 'center', alignItems: 'center' },
  sendBtnDisabled: { backgroundColor: '#ccc' },
  sendIcon: { color: 'white', fontSize: 20, transform: [{ translateX: 1 }] },
});

const modalStyles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  content: { backgroundColor: 'white', padding: 25, borderRadius: 8, width: '90%', maxWidth: 400, minHeight: 200 },
  title: { fontSize: 18, fontWeight: 'bold', marginBottom: 20, textAlign: 'center' },
  categoryContainer: { marginBottom: 20, borderWidth: 1, borderColor: '#ccc', borderRadius: 5, overflow: 'hidden' },
  categoryItem: { padding: 10, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#eee' },
  categoryItemSelected: { backgroundColor: '#e8f0ff' },
  categoryText: { fontSize: 16 },
  buttons: { flexDirection: 'row', justifyContent: 'flex-end', gap: 10, marginTop: 10 },
  button: { paddingVertical: 8, paddingHorizontal: 16, borderRadius: 6, minWidth: 80, alignItems: 'center' },
  cancelBtn: { backgroundColor: '#f0f0f0' },
  confirmBtn: { backgroundColor: '#4a90e2' },
  cancelText: { fontSize: 14 },
  confirmText: { color: 'white', fontSize: 14 },
  confirmationArea: { alignItems: 'center', paddingVertical: 20 },
  confirmationTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 10, padding: 10, backgroundColor: '#f5f5f5', borderRadius: 4 },
  confirmationText: { fontSize: 16, textAlign: 'center', marginBottom: 30, lineHeight: 22 },
  confirmationButtons: { justifyContent: 'space-around', width: '100%', paddingHorizontal: 20 },
  revertBtn: { backgroundColor: '#f0f0f0', borderColor: '#ccc', borderWidth: 1, minWidth: 100 },
  revertText: { fontSize: 14, color: '#333' },
  finalConfirmBtn: { backgroundColor: '#4a90e2', minWidth: 100 },
  finalConfirmText: { color: 'white', fontSize: 14 },
});