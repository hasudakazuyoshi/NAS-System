// app/(app)/explore.tsx

import { useRouter } from 'expo-router';
import React, { useCallback, useState } from 'react';
import {
  Dimensions,
  Platform,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View
} from 'react-native';

// app/(app)/explore.tsx の上部

import HeartRateScreen from './HeartRateScreen';
import SleepChartScreen from './SleepChartScreen';
const { width } = Dimensions.get('window');

type Tab = 'sleep' | 'vitals';

export default function ExploreScreen() {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<Tab>('sleep');
// ... (中略、スタイル定義までそのまま) ...
// スタイル定義は省略しますが、ファイル全体を上書きしてください。
// ...
// (中略、スタイル定義までそのまま) ...
  const goBack = useCallback(() => {
    router.back();
  }, [router]);

  const BackButton = () => (
    <TouchableOpacity onPress={goBack} style={styles.backButton}>
      <Text style={styles.backButtonText}>← 一覧へ戻る</Text>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.safeArea}>
      
      <View style={styles.pageContainer}>
        
        <View style={styles.topBar}>
          <BackButton />
        </View>

        <Text style={styles.title}>グラフ</Text>

        <View style={styles.tabContainer}>
          
          <TouchableOpacity
            style={[styles.tabButton, activeTab === 'sleep' && styles.activeTabButton]}
            onPress={() => setActiveTab('sleep')}
          >
            <Text style={[styles.tabText, activeTab === 'sleep' && styles.activeTabText]}>睡眠時間</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.tabButton, activeTab === 'vitals' && styles.activeTabButton]}
            onPress={() => setActiveTab('vitals')}
          >
            <Text style={[styles.tabText, activeTab === 'vitals' && styles.activeTabText]}>心拍・体温</Text>
          </TouchableOpacity>

        </View>

        <View style={styles.contentContainer}>
          {activeTab === 'sleep' && <SleepChartScreen />}
          {activeTab === 'vitals' && <HeartRateScreen />}
        </View>

      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#fff',
  },
  pageContainer: {
    flex: 1,
    paddingHorizontal: 15,
    paddingTop: 10,
    backgroundColor: '#FEF1E7',
  },
  topBar: {
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'flex-start',
    marginBottom: 20,
    paddingHorizontal: 5,
  },
  backButton: {
    backgroundColor: '#f1f1f1',
    borderWidth: 1,
    borderColor: '#ccc',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 6,
  },
  backButtonText: {
    fontSize: 14,
    color: '#333',
    fontWeight: 'normal',
  },
  title: {
    width: '100%',
    textAlign: 'center',
    color: '#333',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 30,
  },
  tabContainer: {
    flexDirection: 'row',
    width: '100%',
    backgroundColor: '#E0E0E0',
    borderRadius: 8,
    marginBottom: 20,
    padding: 3,
    alignSelf: 'center',
    maxWidth: 400,
  },
  tabButton: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 6,
    alignItems: 'center',
    justifyContent: 'center',
  },
  activeTabButton: {
    backgroundColor: '#FFFFFF',
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.1,
        shadowRadius: 2,
      },
      android: {
        elevation: 3,
      },
    }),
  },
  tabText: {
    fontSize: 16,
    color: '#666',
    fontWeight: '600',
  },
  activeTabText: {
    color: '#4A90E2',
    fontWeight: 'bold',
  },
  contentContainer: {
    flex: 1,
    alignSelf: 'center',
    width: '100%',
    maxWidth: 400,
  }
});