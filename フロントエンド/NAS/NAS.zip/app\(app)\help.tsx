import { Link, useNavigation } from 'expo-router';
import React, { useEffect, useRef, useState } from 'react';
import {
    ActivityIndicator,
    Keyboard,
    SafeAreaView,
    ScrollView,
    StyleSheet,
    Text,
    TextInput,
    TouchableOpacity,
    View
} from 'react-native';

// ★変更点1：新しいAPIサービスを使う
// @ts-ignore
import { sendChatbotMessage } from '../../api/apiService';

type Message = {
  id: number;
  text: string;
  sender: 'user' | 'assistant';
};

export default function HelpScreen() {
  const navigation = useNavigation();
  const [messageInput, setMessageInput] = useState('');
  const [isLoading, setIsLoading] = useState(false); // 通信中フラグ
  
  const scrollViewRef = useRef<ScrollView>(null); 

  // 初期メッセージ
  const [messages, setMessages] = useState<Message[]>([
    { 
      id: 1, 
      text: 'こんにちは！システムのシステムです。機能についてお尋ねください。', 
      sender: 'assistant' 
    }
  ]);

  // メッセージが増えたら一番下にスクロール
  useEffect(() => {
    if (scrollViewRef.current) {
      setTimeout(() => {
        scrollViewRef.current?.scrollToEnd({ animated: true });
      }, 100);
    }
  }, [messages]);

  const handleSendMessage = async () => {
    const textToSend = messageInput.trim();
    if (!textToSend) return;

    // 1. まずユーザーのメッセージを画面に表示
    const userMsg: Message = {
      id: Date.now(),
      text: textToSend,
      sender: 'user', 
    };
    
    setMessages(prev => [...prev, userMsg]);
    setMessageInput('');
    Keyboard.dismiss();
    setIsLoading(true);

    try {
      // ★変更点2：apiServiceの関数を使う（URLやPOST指定が不要になりスッキリ！）
      // Django担当者のコードにある「sendChatbotMessage」を使用
      const data = await sendChatbotMessage(textToSend);

      // 3. サーバーからの返事を表示
      // (サーバーが { "answer": "..." } または { "message": "..." } で返してくると想定)
      const assistantMsg: Message = {
        id: Date.now() + 1,
        text: data.answer || data.message || '回答を取得できませんでした。',
        sender: 'assistant'
      };
      setMessages(prev => [...prev, assistantMsg]);

    } catch (error) {
      console.error("通信エラー:", error);
      const errorMsg: Message = {
        id: Date.now() + 1,
        text: 'サーバーに接続できませんでした。',
        sender: 'assistant'
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };
  
  const MessageBubble = ({ message }: { message: Message }) => {
    const isUser = message.sender === 'user';
    return (
      <View style={[
        styles.messageRow,
        isUser ? styles.userMessageRow : styles.assistantMessageRow
      ]}>
        <View style={[
          styles.bubble,
          isUser ? styles.userBubble : styles.assistantBubble,
          isUser ? styles.userBorderRadius : styles.assistantBorderRadius
        ]}>
          <Text style={isUser ? styles.userText : styles.assistantText}>
            {message.text}
          </Text>
        </View>
      </View>
    );
  };

  const Header = () => (
    <View style={styles.header}>
      {/* 戻り先: 利用者ホーム */}
      <Link href="/(app)/user-home" asChild>
        <TouchableOpacity style={styles.backButton}>
          <Text style={styles.backButtonText}>← ホームへ戻る</Text>
        </TouchableOpacity>
      </Link>
      
      {/* お問い合わせボタン */}
      <Link href="/contact-form" asChild> 
        <TouchableOpacity style={styles.contactButton}>
          <Text style={styles.contactButtonText}>お問い合わせフォーム</Text>
        </TouchableOpacity>
      </Link>
    </View>
  );

  return (
    <SafeAreaView style={styles.safeArea}>
      <Header />

      <ScrollView 
        ref={scrollViewRef}
        style={styles.chatContainer}
        contentContainerStyle={styles.chatContentContainer}
      >
        {messages.map(message => (
          <MessageBubble key={message.id} message={message} />
        ))}
        
        {/* 読み込み中の表示 */}
        {isLoading && (
          <View style={[styles.messageRow, styles.assistantMessageRow]}>
            <View style={[styles.bubble, styles.assistantBubble, styles.assistantBorderRadius]}>
              <ActivityIndicator size="small" color="#999" />
            </View>
          </View>
        )}
      </ScrollView>

      <View style={styles.inputArea}>
        <TextInput
          style={styles.textInput}
          placeholder="わからないところを入力"
          placeholderTextColor="#999"
          value={messageInput}
          onChangeText={setMessageInput}
          editable={!isLoading} // 通信中は入力不可
        />
        <TouchableOpacity 
          style={[styles.sendButton, (!messageInput.trim() || isLoading) && styles.sendButtonDisabled]} 
          onPress={handleSendMessage}
          disabled={!messageInput.trim() || isLoading}
        >
          <Text style={styles.sendButtonText}>送信</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

// --- スタイルシート ---

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#FEF1E7', 
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 15,
    paddingVertical: 10,
    backgroundColor: '#FEF1E7', 
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  backButton: { 
    paddingVertical: 5, 
    paddingHorizontal: 10, 
    backgroundColor: '#f0f0f0', 
    borderRadius: 5, 
  },
  backButtonText: { 
    fontSize: 16, 
    color: '#333', 
  },
  contactButton: { 
    paddingVertical: 5, 
    paddingHorizontal: 10, 
    backgroundColor: '#f0f0f0', 
    borderRadius: 5, 
  },
  contactButtonText: { 
    fontSize: 16, 
    color: '#333', 
  },
  
  chatContainer: {
    flex: 1,
    padding: 15,
    backgroundColor: '#FEF1E7', 
  },
  chatContentContainer: {
    paddingBottom: 20,
  },
  
  messageRow: {
    marginBottom: 10,
    maxWidth: '80%',
  },
  assistantMessageRow: {
    alignSelf: 'flex-start',
  },
  userMessageRow: {
    alignSelf: 'flex-end',
  },
  bubble: {
    padding: 10,
    borderRadius: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 1,
    elevation: 2,
  },
  assistantBubble: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#ddd',
  },
  assistantBorderRadius: {
    borderTopLeftRadius: 5,
  },
  assistantText: {
    fontSize: 16,
    color: '#333',
  },
  userBubble: {
    backgroundColor: '#DCF8C6',
  },
  userBorderRadius: {
    borderTopRightRadius: 5,
  },
  userText: {
    fontSize: 16,
    color: '#333',
  },
  inputArea: {
    flexDirection: 'row',
    padding: 10,
    backgroundColor: '#fff',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: '#eee',
  },
  textInput: {
    flex: 1,
    height: 40,
    backgroundColor: '#f0f0f0',
    borderRadius: 20,
    paddingHorizontal: 15,
    marginRight: 10,
    fontSize: 16,
  },
  sendButton: {
    height: 40,
    borderRadius: 5,
    backgroundColor: '#1E90FF',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 15,
    minWidth: 60,
  },
  sendButtonDisabled: {
    backgroundColor: '#ccc',
  },
  sendButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  }
});