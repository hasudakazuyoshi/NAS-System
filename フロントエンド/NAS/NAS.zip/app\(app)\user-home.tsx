import { FontAwesome } from '@expo/vector-icons';
import { Link } from 'expo-router';
import React from 'react';
import {
  Platform,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View
} from 'react-native';

export default function UserHomeScreen() {
  return (
    <SafeAreaView style={styles.safeArea}>
      
      {/* HTMLの .container にあたる部分 */}
      <View style={styles.container}>
        
        {/* HTMLの .mascot-icon */}
        <FontAwesome
          name="cat"
          size={50}
          color="#8BC34A" 
          style={styles.mascotIcon}
        />
        
        {/* HTMLの h1 */}
        <Text style={styles.title}>利用者ホーム</Text>

        {/* HTMLの .button (1つ目: 利用者情報) */}
        <Link href="/(app)/user-info" asChild>
          <TouchableOpacity style={styles.button}>
            <Text style={styles.buttonText}>利用者情報</Text>
          </TouchableOpacity>
        </Link>

        {/* HTMLの .button (2つ目: グラフ) */}
        <Link href="/(app)/explore" asChild>
          <TouchableOpacity style={styles.button}>
            <Text style={styles.buttonText}>グラフ</Text>
          </TouchableOpacity>
        </Link>

        {/* HTMLの .button (3つ目: ヘルプ) */}
        <Link href="/(app)/help" asChild>
          <TouchableOpacity style={styles.button}>
            <Text style={styles.buttonText}>ヘルプ</Text>
          </TouchableOpacity>
        </Link>

      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    // HTMLの body background-color: #FEF1E7
    backgroundColor: '#FEF1E7',
    justifyContent: 'center',
    alignItems: 'center',
  },
  container: {
    // HTMLの .container
    width: '90%', // モバイル向けに調整（HTMLのpaddingだとスマホではみ出るため）
    maxWidth: 400,
    backgroundColor: '#fff',
    paddingVertical: 40,
    paddingHorizontal: 30,
    borderRadius: 16,
    alignItems: 'center',
    
    // HTMLの box-shadow
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 8 },
        shadowOpacity: 0.08,
        shadowRadius: 25,
      },
      android: {
        elevation: 8,
      },
    }),
  },
  mascotIcon: {
    // HTMLの .mascot-icon margin-bottom: 20px
    marginBottom: 20,
  },
  title: {
    // HTMLの h1
    fontSize: 26,
    color: '#333',
    marginTop: 0,
    marginBottom: 30,
    fontWeight: '600',
    textAlign: 'center',
  },
  button: {
    // HTMLの .button
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    width: 250, // HTMLの width: 250px
    marginVertical: 9, // HTMLの margin: 18px auto (上下9ずつ)
    paddingVertical: 16, // HTMLの padding: 16px
    backgroundColor: '#8BC34A', // HTMLの color
    borderRadius: 10,
    
    // HTMLの box-shadow (ボタン用)
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 3 },
        shadowOpacity: 0.1,
        shadowRadius: 8,
      },
      android: {
        elevation: 4,
      },
    }),
  },
  buttonText: {
    fontSize: 19, // HTMLの font-size: 19px
    color: 'white',
    fontWeight: '600',
  },
});