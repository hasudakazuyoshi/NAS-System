import { Picker } from '@react-native-picker/picker';
import { useRouter } from 'expo-router';
import React, { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Platform,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View
} from 'react-native';

// ★ここが変わりました！新しいAPIサービスを読み込みます
// (../.. で2つ上の階層に上がり、apiフォルダの中を見に行きます)
// @ts-ignore
import { getUserInfo, updateUserInfo } from '../../api/apiService';

// Bluetooth用ライブラリ (Web以外で読み込み)
let manager: any;
let BleManager: any;

if (Platform.OS !== 'web') {
  try {
    BleManager = require('react-native-ble-plx').BleManager;
    manager = new BleManager();
  } catch (e) {
    console.log("Bluetoothライブラリがまだインストールされていないか、リンクされていません。");
  }
}

const INITIAL_DEVICE = { id: '', name: '未選択' };
type Device = { id: string; name: string };

export default function UserInfoScreen() {
  const router = useRouter();
  
  // 入力データ
  const [height, setHeight] = useState('');
  const [weight, setWeight] = useState('');
  const [wearable, setWearable] = useState(INITIAL_DEVICE.id);
  
  // 表示のみのデータ
  const [dateOfBirth, setDateOfBirth] = useState('未設定');
  const [gender, setGender] = useState('未設定');

  // 変更検知用の初期値
  const [initialData, setInitialData] = useState({ 
    height: '', weight: '', wearable: INITIAL_DEVICE.id 
  });

  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [devices, setDevices] = useState<Device[]>([INITIAL_DEVICE]);

  // ★変更点：画面を開いた時に「getUserInfo()」を使う
  useEffect(() => {
    const fetchUserInfo = async () => {
      setIsLoading(true);
      try {
        // すごくシンプルになりました！
        const data = await getUserInfo();
        
        // データのセット
        const h = data.height ? String(data.height) : '';
        const w = data.weight ? String(data.weight) : '';
        const dev = data.wearable || INITIAL_DEVICE.id;

        setHeight(h);
        setWeight(w);
        setWearable(dev);
        setDateOfBirth(data.birthDate || '1990/01/01');
        setGender(data.gender || '不明');

        setInitialData({ height: h, weight: w, wearable: dev });
        
      } catch (error) {
        console.log("データ取得エラー（初回は空でOK）");
      } finally {
        setIsLoading(false);
      }
    };
    fetchUserInfo();
  }, []);

  // 変更があるか判定
  const hasChanges = 
    height !== initialData.height || 
    weight !== initialData.weight || 
    wearable !== initialData.wearable;

  // Bluetooth検索機能
  const searchDevices = async () => {
    if (Platform.OS === 'web' || !manager) {
      Alert.alert('確認', 'Bluetooth検索機能を使うには、ライブラリのインストールが必要です。');
      return;
    }

    setIsSearching(true);
    setDevices([{ id: '', name: '検索中...' }]);
    
    // ダミー検索（実際は manager.startDeviceScan）
    setTimeout(() => {
      const foundDevices = [
        { id: 'dev1', name: 'My Watch' },
        { id: 'dev2', name: 'Smart Ring' }
      ];
      setDevices([INITIAL_DEVICE, ...foundDevices]);
      setIsSearching(false);
      Alert.alert('検索完了', `${foundDevices.length}件の機器が見つかりました。`);
    }, 2000);
  };

  // ★変更点：保存時に「updateUserInfo()」を使う
  const handleSave = async () => {
    setIsSaving(true);
    try {
      // これだけでサーバーに保存できます！
      await updateUserInfo({
        height: parseFloat(height),
        weight: parseFloat(weight),
        wearable: wearable
      });

      Alert.alert("保存完了", "情報を更新しました！");
      setInitialData({ height, weight, wearable });

    } catch (error) {
      Alert.alert("エラー", "保存できませんでした。");
    } finally {
      setIsSaving(false);
    }
  };

  // 戻る処理
  const handleBack = () => {
    if (hasChanges) {
      Alert.alert(
        "確認",
        "保存されていない変更があります。戻りますか？",
        [
          { text: "キャンセル", style: "cancel" },
          { text: "戻る", onPress: () => router.back() }
        ]
      );
    } else {
      router.back();
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.pageContainer}>
        
        {/* 上部バー */}
        <View style={styles.topBar}>
          <TouchableOpacity onPress={handleBack} style={styles.backButton}>
            <Text style={styles.backButtonText}>← 戻る</Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.title}>利用者情報</Text>

        {isLoading ? (
          <ActivityIndicator size="large" color="#4a90e2" />
        ) : (
          <>
            {/* ① アカウント情報 */}
            <View style={styles.infoSection}>
              <View style={styles.infoRow}>
                <Text style={styles.infoLabel}>メールアドレス ID</Text>
                <TouchableOpacity style={styles.changeButton}>
                  <Text style={styles.changeButtonText}>変更</Text>
                </TouchableOpacity>
              </View>
              <View style={styles.infoRow}>
                <Text style={styles.infoLabel}>パスワード</Text>
                <TouchableOpacity style={styles.changeButton}>
                  <Text style={styles.changeButtonText}>変更</Text>
                </TouchableOpacity>
              </View>
            </View>

            {/* ② 静的情報 */}
            <View style={[styles.infoSection, styles.staticInfoRow]}>
              <Text>生年月日: <Text style={styles.infoValue}>{dateOfBirth}</Text></Text>
              <Text>性別: <Text style={styles.infoValue}>{gender}</Text></Text>
            </View>

            {/* ③ 編集可能エリア */}
            <View style={styles.infoSection}>
              <View style={styles.inputRow}>
                <Text style={styles.inputLabel}>身長 (cm)</Text>
                <TextInput
                  style={styles.textInput}
                  value={height}
                  onChangeText={setHeight}
                  keyboardType="numeric"
                  placeholder="例: 170.0"
                />
              </View>
              <View style={styles.inputRow}>
                <Text style={styles.inputLabel}>体重 (kg)</Text>
                <TextInput
                  style={styles.textInput}
                  value={weight}
                  onChangeText={setWeight}
                  keyboardType="numeric"
                  placeholder="例: 65.0"
                />
              </View>
            </View>

            {/* ④ ウェアラブル選択 */}
            <View style={styles.infoSection}>
              <Text style={styles.inputLabel}>ウェアラブル機器</Text>
              <View style={styles.deviceSelectRow}>
                <View style={styles.pickerContainer}>
                  <Picker
                    selectedValue={wearable}
                    onValueChange={(val) => setWearable(val)}
                    style={styles.picker}
                  >
                    {devices.map((d, i) => (
                      <Picker.Item key={i} label={d.name} value={d.id} />
                    ))}
                  </Picker>
                </View>
                <TouchableOpacity 
                  style={[styles.searchButton, isSearching && styles.disabledButton]}
                  onPress={searchDevices}
                  disabled={isSearching}
                >
                  <Text style={styles.searchButtonText}>
                    {isSearching ? '...' : '検索'}
                  </Text>
                </TouchableOpacity>
              </View>
            </View>

            {/* ⑤ 保存ボタン */}
            <TouchableOpacity
              style={[styles.saveButton, (!hasChanges || isSaving) && styles.disabledButton]}
              onPress={handleSave}
              disabled={!hasChanges || isSaving}
            >
              <Text style={styles.saveButtonText}>保存</Text>
            </TouchableOpacity>
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#FEF3EC' },
  pageContainer: { padding: 20, alignItems: 'center' },
  topBar: { width: '100%', marginBottom: 20, flexDirection: 'row' },
  backButton: { backgroundColor: '#f1f1f1', padding: 10, borderRadius: 6, borderWidth: 1, borderColor: '#ccc' },
  backButtonText: { color: '#333' },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20, color: '#333' },
  infoSection: { 
    width: '100%', backgroundColor: 'white', padding: 20, borderRadius: 8, marginBottom: 20,
    ...Platform.select({
      ios: { shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.1, shadowRadius: 3 },
      android: { elevation: 2 },
    }),
  },
  infoRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 15, alignItems: 'center' },
  infoLabel: { fontWeight: 'bold', fontSize: 16, color: '#333' },
  changeButton: { backgroundColor: '#C8E6C9', paddingVertical: 6, paddingHorizontal: 15, borderRadius: 6 },
  changeButtonText: { fontSize: 12, fontWeight: 'bold', color: '#333' },
  infoValue: { color: '#555', fontWeight: 'bold' },
  staticInfoRow: { flexDirection: 'row', justifyContent: 'space-around' },
  inputRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 15 },
  inputLabel: { width: 80, fontWeight: 'bold', fontSize: 16, color: '#333' },
  textInput: { flex: 1, borderWidth: 1, borderColor: '#ccc', borderRadius: 6, padding: 8, backgroundColor: '#fff', fontSize: 16 },
  deviceSelectRow: { flexDirection: 'row', marginTop: 10 },
  pickerContainer: { flex: 1, borderWidth: 1, borderColor: '#ccc', borderRadius: 6, marginRight: 10, height: 40, justifyContent: 'center' },
  picker: { width: '100%' },
  searchButton: { backgroundColor: '#6c757d', padding: 10, borderRadius: 6, justifyContent: 'center' },
  searchButtonText: { color: 'white' },
  saveButton: { backgroundColor: '#4a90e2', padding: 15, borderRadius: 6, width: '100%', alignItems: 'center' },
  saveButtonText: { color: 'white', fontWeight: 'bold', fontSize: 18 },
  disabledButton: { backgroundColor: '#ccc' },
});