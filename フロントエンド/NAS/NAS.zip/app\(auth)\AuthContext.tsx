import React, { createContext, useContext, useEffect, useState } from 'react';
import { login as apiLogin, logout as apiLogout, getAccessToken } from '../../api/apiService.js';

interface User {
  id: string;
  email: string;
}

interface AuthContextType {
  user: User | null;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    const checkLoginStatus = async () => {
      try {
        const token = await getAccessToken();
        if (token) {
          setUser({ id: 'restored_user', email: 'unknown' });
        }
      } catch (e) {
        console.log('ログイン状態の確認に失敗しました');
      } finally {
        setIsLoading(false);
      }
    };
    checkLoginStatus();
  }, []);

  const signIn = async (email: string, password: string) => {
    try {
      const response = await apiLogin(email, password);

      if (response.user) {
        setUser({
          id: response.user.user_id,
          email: response.user.email,
        });
      }
    } catch (error) {
      throw error;
    }
  };

  const signOut = async () => {
    try {
      await apiLogout();
    } catch (error) {
      console.error('ログアウトエラー:', error);
    } finally {
      setUser(null);
    }
  };

  return (
    <AuthContext.Provider value={{ user, signIn, signOut, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
