import { useRouter } from 'expo-router';
import React from 'react';
import { SafeAreaView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';

const IdentityVerificationComplete: React.FC = () => {
    const router = useRouter();

    const handlePress = () => {
        // OKボタンを押したら、次の「ユーザー情報登録画面 (user_register)」へ遷移
        // 戻る必要はないので replace を使用します
        router.replace('/user_register');
    };

    return (
        <SafeAreaView style={styles.safeArea}>
            <View style={styles.container}>
                
                {/* 緑色の円とチェックマーク */}
                <View style={styles.iconContainer}>
                    <View style={styles.checkmark} />
                </View>

                {/* メッセージ */}
                <Text style={styles.message}>
                    本人確認が完了しました
                </Text>

                {/* OKボタン (二重枠線デザインを再現) */}
                <View style={styles.okButtonContainer}>
                    <TouchableOpacity 
                        style={styles.okButton} 
                        onPress={handlePress}
                        activeOpacity={0.7}
                    >
                        <Text style={styles.okButtonText}>OK</Text>
                    </TouchableOpacity>
                </View>

            </View>
        </SafeAreaView>
    );
};

export default IdentityVerificationComplete;

// --- スタイル定義 ---
const styles = StyleSheet.create({
    safeArea: {
        flex: 1,
        backgroundColor: '#FEF3EC', // HTMLの body background-color
    },
    container: {
        flex: 1,
        justifyContent: 'center', // 上下中央揃え (flex-direction: column はデフォルト)
        alignItems: 'center',     // 左右中央揃え
        padding: 20,
    },
    // 緑色の円 (.icon-container)
    iconContainer: {
        width: 100,
        height: 100,
        backgroundColor: '#C8E6C9',
        borderRadius: 50, // 正円にするため width/2
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 30,
    },
    // チェックマーク (.checkmark)
    // CSSの border テクニックをそのままRNで再現
    checkmark: {
        width: 40,
        height: 60, // HTMLのサイズに合わせました
        borderBottomWidth: 8,
        borderRightWidth: 8,
        borderColor: 'white',
        transform: [{ rotate: '45deg' }],
        marginTop: -10, // 回転の中心位置調整で見かけ上の真ん中に寄せる
    },
    // メッセージ (.message)
    message: {
        fontSize: 28,
        fontWeight: 'bold',
        color: '#333',
        textAlign: 'center',
        marginBottom: 50,
        lineHeight: 45, // line-height: 1.6 近似 (28 * 1.6 ≈ 44.8)
    },
    // ボタンの外枠 (.ok-button-container)
    okButtonContainer: {
        backgroundColor: '#ccc',
        padding: 2, // 枠線の太さに相当
        borderRadius: 8,
        // 影をつけて少しリッチに (HTMLの box-shadow 再現)
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
        elevation: 2,
    },
    // ボタン本体 (.ok-button)
    okButton: {
        width: 120,
        height: 45,
        backgroundColor: 'white',
        borderRadius: 6,
        alignItems: 'center',
        justifyContent: 'center',
    },
    okButtonText: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#333',
    },
});