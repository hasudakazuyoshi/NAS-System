import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  SafeAreaView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';

// @ts-ignore
import { useAuth } from './AuthContext';

const LoginScreen: React.FC = () => {
  const router = useRouter();
  
  const { signIn } = useAuth();

  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [isPasswordVisible, setIsPasswordVisible] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  
  const activeTab = 'login'; 

  // ■ ログイン処理
  const handleLogin = async (): Promise<void> => {
    if (!email || !password) {
      Alert.alert('エラー', 'メールアドレスとパスワードを入力してください。');
      return;
    }

    setLoading(true);
    try {
      await signIn(email, password);
      
      Alert.alert(
        'ログイン成功', 
        `ユーザーID: ${email} でログインしました。`,
        [
          {
            text: 'OK',
            onPress: () => {
              router.replace('/(app)/user-home'); 
            }
          }
        ]
      );
      
    } catch (error: any) {
      console.error("ログインエラー:", error);
      
      let errorMessage = error.message || '通信エラーが発生しました。';
      if (errorMessage.includes('Unexpected character: <')) {
        errorMessage = 'サーバーのURL設定エラー、またはメンテナンス中です。\n(HTMLが返ってきています)';
      }
      Alert.alert('ログイン失敗', errorMessage);
    } finally {
      setLoading(false);
    }
  };

  // ■ 新規登録画面へ遷移
  const handleRegister = (): void => {
    router.push('/(auth)/register'); 
  };

  // ★修正ポイント：パスワード忘れリンクを押すと mail_send へ移動！
  const handleForgotPassword = (): void => {
    // mail_send.tsx が app/ 直下にある場合、パスは '/mail_send' です
    router.push('/mail_send');
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <Text style={styles.title}>🍃NASシステム</Text>

        {/* タブグループ */}
        <View style={styles.buttonGroup}>
          <TouchableOpacity
            style={[styles.tabButton, activeTab === 'login' && styles.tabButtonActive, styles.tabButtonLeft]}
            onPress={() => {}}
            disabled={loading}
          >
            <Text style={[styles.tabButtonText, activeTab === 'login' && styles.tabButtonTextActive]}>
              ログイン
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.tabButton, activeTab !== 'login' && styles.tabButtonActive, styles.tabButtonRight]}
            onPress={handleRegister}
            disabled={loading}
          >
            <Text style={[styles.tabButtonText, activeTab !== 'login' && styles.tabButtonTextActive]}>
              新規利用者登録
            </Text>
          </TouchableOpacity>
        </View>

        {/* フォーム部分 */}
        <View style={styles.form}>
          <Text style={styles.label}>メールアドレス</Text>
          <TextInput
            style={styles.input}
            value={email}
            onChangeText={setEmail}
            placeholder="登録しているIDを入力してください"
            keyboardType="email-address"
            autoCapitalize="none"
            editable={!loading}
          />

          <Text style={styles.label}>パスワード</Text>
          <View style={styles.inputGroup}>
            <TextInput
              style={styles.input}
              value={password}
              onChangeText={setPassword}
              placeholder="パスワードを入力してください"
              secureTextEntry={!isPasswordVisible}
              editable={!loading}
            />
            <TouchableOpacity
              style={styles.togglePassword}
              onPress={() => setIsPasswordVisible(!isPasswordVisible)}
              disabled={loading}
            >
              <Text style={styles.togglePasswordText}>
                {isPasswordVisible ? "👁️" : "🙈"}
              </Text>
            </TouchableOpacity>
          </View>

          <TouchableOpacity
            style={[styles.loginButton, loading && styles.loginButtonDisabled]}
            onPress={handleLogin}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color="white" />
            ) : (
              <Text style={styles.loginButtonText}>ログイン</Text>
            )}
          </TouchableOpacity>
        </View>

        {/* パスワード忘れリンク */}
        <TouchableOpacity onPress={handleForgotPassword} disabled={loading}>
          <Text style={styles.forgotPassword}>
            パスワードを忘れた場合はこちら
          </Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

export default LoginScreen;

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#fce2c4',
  },
  container: {
    flex: 1,
    backgroundColor: '#fce2c4',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 30,
    color: '#333',
    textAlign: 'center',
  },
  buttonGroup: {
    flexDirection: 'row',
    justifyContent: 'center',
    width: '100%',
    marginBottom: 35,
    maxWidth: 360,
  },
  tabButton: {
    flex: 1,
    paddingVertical: 12,
    borderWidth: 2,
    borderColor: '#0078D7',
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 0, 
  },
  tabButtonLeft: {
    borderTopLeftRadius: 8,
    borderBottomLeftRadius: 8,
    marginRight: -2,
  },
  tabButtonRight: {
    borderTopRightRadius: 8,
    borderBottomRightRadius: 8,
  },
  tabButtonActive: {
    backgroundColor: '#0078D7',
    borderColor: '#0078D7',
  },
  tabButtonText: {
    color: '#0078D7',
    fontSize: 16,
    fontWeight: 'bold',
  },
  tabButtonTextActive: {
    color: 'white',
  },
  form: {
    width: '100%',
    maxWidth: 360,
  },
  label: {
    textAlign: 'left',
    marginTop: 15,
    color: '#444',
    fontWeight: 'bold',
    fontSize: 14,
  },
  inputGroup: {
    position: 'relative',
    width: '100%',
    marginBottom: 35,
  },
  input: {
    width: '100%',
    height: 40,
    paddingHorizontal: 10,
    marginTop: 6,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    fontSize: 14,
    backgroundColor: 'white',
    paddingRight: 40,
  },
  togglePassword: {
    position: 'absolute',
    right: 10,
    top: 6 + 20 - 9, 
    padding: 5,
  },
  togglePasswordText: {
    fontSize: 18,
    color: '#666',
  },
  loginButton: {
    width: '100%',
    paddingVertical: 12,
    backgroundColor: '#28a745',
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  loginButtonDisabled: {
    backgroundColor: '#71c083',
  },
  loginButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  forgotPassword: {
    marginTop: 20,
    fontSize: 14,
    color: '#0078D7',
    textDecorationLine: 'underline',
  },
});