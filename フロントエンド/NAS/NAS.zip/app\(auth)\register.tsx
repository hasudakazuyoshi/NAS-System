import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import {
    ActivityIndicator,
    Alert,
    SafeAreaView,
    ScrollView,
    StyleSheet,
    Text,
    TextInput,
    TouchableOpacity,
    View,
} from 'react-native';

const RegisterScreen: React.FC = () => {
    const router = useRouter();
    
    // 状態管理
    const [email, setEmail] = useState<string>('');
    const [loading, setLoading] = useState<boolean>(false);
    
    // この画面は新規登録画面なので、アクティブタブは 'register' で固定
    const activeTab = 'register'; 

    // 新規登録処理
    const handleRegister = async (): Promise<void> => {
        // メールアドレスの有無チェック
        if (!email) {
            Alert.alert('エラー', 'メールアドレスを入力してください。');
            return;
        }

        setLoading(true);
        try {
            // ⭐ 実際のAPIコール（新規登録処理）をここに実装します
            
            // ダミーの認証処理（1.5秒待機）
            await new Promise(resolve => setTimeout(resolve, 1500));
            
            setLoading(false);
            
            // 変更点: 完了画面へ遷移 (メールアドレスをパラメータとして渡す)
            router.replace({
                pathname: '/ProvisionalRegistrationComplete',
                params: { email: email }
            });
            
        } catch (error) {
            setLoading(false);
            Alert.alert('登録失敗', '登録中にエラーが発生しました。');
        }
    };

    return (
        <SafeAreaView style={styles.safeArea}>
            <ScrollView contentContainerStyle={styles.scrollContainer}>
                <View style={styles.container}>
                    <Text style={styles.title}>🍃NASシステム</Text>

                    {/* タブグループ */}
                    <View style={styles.buttonGroup}>
                        <TouchableOpacity
                            style={[styles.tabButton, activeTab !== 'register' && styles.tabButtonActive, styles.tabButtonLeft]}
                            // ログインタブを押したらログイン画面へ戻る
                            onPress={() => router.replace('/')} 
                            disabled={loading}
                        >
                            <Text style={[styles.tabButtonText, activeTab !== 'register' && styles.tabButtonTextActive]}>
                                ログイン
                            </Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                            style={[styles.tabButton, activeTab === 'register' && styles.tabButtonActive, styles.tabButtonRight]}
                            onPress={() => {}}
                            disabled={loading}
                        >
                            <Text style={[styles.tabButtonText, activeTab === 'register' && styles.tabButtonTextActive]}>
                                新規利用者登録
                            </Text>
                        </TouchableOpacity>
                    </View>

                    {/* フォーム部分 */}
                    <View style={styles.form}>
                        
                        {/* メールアドレス */}
                        <Text style={styles.label}>メールアドレス</Text>
                        <View style={styles.inputGroup}>
                            <TextInput
                                style={styles.input}
                                value={email}
                                onChangeText={setEmail}
                                placeholder="メールアドレスを入力してください"
                                keyboardType="email-address"
                                autoCapitalize="none"
                                editable={!loading}
                            />
                        </View>
                        
                        {/* 登録ボタン */}
                        <TouchableOpacity
                            style={[styles.registerButton, loading && styles.registerButtonDisabled]}
                            onPress={handleRegister}
                            disabled={loading}
                        >
                            {loading ? (
                                <ActivityIndicator color="white" />
                            ) : (
                                <Text style={styles.registerButtonText}>登録</Text>
                            )}
                        </TouchableOpacity>
                    </View>
                </View>
            </ScrollView>
        </SafeAreaView>
    );
};

export default RegisterScreen;

// --- スタイルシート ---
const styles = StyleSheet.create({
    safeArea: {
        flex: 1,
        backgroundColor: '#fce2c4',
    },
    scrollContainer: {
        flexGrow: 1, 
        justifyContent: 'center',
    },
    container: {
        backgroundColor: '#fce2c4',
        alignItems: 'center',
        padding: 20,
        width: '100%',
        maxWidth: 400,
        alignSelf: 'center',
    },
    title: {
        fontSize: 28,
        fontWeight: 'bold',
        marginBottom: 30,
        color: '#333',
        textAlign: 'center',
    },
    buttonGroup: {
        flexDirection: 'row',
        justifyContent: 'center',
        width: '100%',
        marginBottom: 35,
    },
    tabButton: {
        flex: 1,
        paddingVertical: 12,
        borderWidth: 2,
        borderColor: '#0078D7',
        backgroundColor: 'white',
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 0,
    },
    tabButtonLeft: {
        borderTopLeftRadius: 8,
        borderBottomLeftRadius: 8,
        marginRight: -2,
    },
    tabButtonRight: {
        borderTopRightRadius: 8,
        borderBottomRightRadius: 8,
    },
    tabButtonActive: {
        backgroundColor: '#0078D7', 
        borderColor: '#0078D7',
    },
    tabButtonText: {
        color: '#0078D7',
        fontSize: 16,
        fontWeight: 'bold',
    },
    tabButtonTextActive: {
        color: 'white',
    },
    form: {
        width: '100%',
    },
    label: {
        textAlign: 'left',
        marginTop: 15,
        color: '#444',
        fontWeight: 'bold',
        fontSize: 14,
    },
    inputGroup: {
        width: '100%',
        marginBottom: 35, 
    },
    input: {
        width: '100%',
        height: 40,
        paddingHorizontal: 10,
        marginTop: 6,
        borderWidth: 1,
        borderColor: '#ccc',
        borderRadius: 8,
        fontSize: 14,
        backgroundColor: 'white',
    },
    registerButton: {
        width: '100%',
        paddingVertical: 12,
        backgroundColor: '#28a745',
        borderWidth: 0, 
        borderRadius: 8,
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 20,
    },
    registerButtonDisabled: {
        backgroundColor: '#71c083',
    },
    registerButtonText: {
        color: 'white',
        fontSize: 16,
        fontWeight: 'bold',
    },
});