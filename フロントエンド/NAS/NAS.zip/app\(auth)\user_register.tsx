import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import {
    ActivityIndicator,
    Alert,
    KeyboardAvoidingView,
    Platform,
    SafeAreaView,
    ScrollView,
    StyleSheet,
    Text,
    TextInput,
    TouchableOpacity,
    View
} from 'react-native';
// 選択リストを使うためのライブラリ
import { Picker } from '@react-native-picker/picker';

// ★APIサービスの読み込み
// @ts-ignore
import { register } from '../../api/apiService';

const RegisterScreen: React.FC = () => {
  const router = useRouter();

  // ■ 入力データ（HTMLの項目に合わせて追加しました）
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [rePassword, setRePassword] = useState<string>('');
  
  // プロフィール項目
  const [gender, setGender] = useState<string>('');
  const [birthdate, setBirthdate] = useState<string>(''); // YYYY-MM-DD形式
  const [height, setHeight] = useState<string>('');
  const [weight, setWeight] = useState<string>('');
  const [device, setDevice] = useState<string>('');

  // UI状態
  const [isPasswordVisible, setIsPasswordVisible] = useState<boolean>(false);
  const [isRePasswordVisible, setIsRePasswordVisible] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  
  // タブの表示用
  const activeTab = 'register'; 

  // ■■■ 新規登録処理 ■■■
  const handleRegister = async (): Promise<void> => {
    // 1. バリデーション
    if (!email || !password || !rePassword || !gender || !birthdate) {
      Alert.alert('エラー', '必須項目（メール, パスワード, 性別, 生年月日）を入力してください。');
      return;
    }
    if (password !== rePassword) {
      Alert.alert('エラー', 'パスワードが一致しません。');
      return;
    }
    if (password.length < 8) {
      Alert.alert('エラー', 'パスワードは8文字以上で設定してください。');
      return;
    }

    setLoading(true);

    try {
      // 2. サーバーへ全データを送信
      // Django側がこれらのフィールド(genderなど)を受け取れる前提です
      await register({
        email: email,
        password: password,
        re_password: rePassword,
        // 追加プロフィール情報
        gender: gender,
        birth_date: birthdate,
        height: height ? parseFloat(height) : null,
        weight: weight ? parseFloat(weight) : null,
        wearable_device: device
      });

      // 3. 成功したら仮登録完了画面へ
      router.replace('/ProvisionalRegistrationComplete'); 

    } catch (error: any) {
      console.error("登録エラー:", error);
      const errorMessage = error.message || '登録処理に失敗しました。';
      Alert.alert('登録失敗', errorMessage);
    } finally {
      setLoading(false);
    }
  };

  // ■■■ ログイン画面へ戻る ■■■
  const handleLoginTransition = (): void => {
    router.push('/(auth)'); 
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1 }}
      >
        <ScrollView contentContainerStyle={styles.scrollContainer}>
          <View style={styles.container}>
            <Text style={styles.title}>🍃利用者新規登録</Text>

            {/* タブグループ */}
            <View style={styles.buttonGroup}>
              <TouchableOpacity
                style={[styles.tabButton, activeTab !== 'register' && styles.tabButtonActive, styles.tabButtonLeft]}
                onPress={handleLoginTransition}
                disabled={loading}
              >
                <Text style={[styles.tabButtonText, activeTab !== 'register' && styles.tabButtonTextActive]}>
                  ログイン
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[styles.tabButton, activeTab === 'register' && styles.tabButtonActive, styles.tabButtonRight]}
                onPress={() => {}}
                disabled={loading}
              >
                <Text style={[styles.tabButtonText, activeTab === 'register' && styles.tabButtonTextActive]}>
                  新規利用者登録
                </Text>
              </TouchableOpacity>
            </View>

            {/* 入力フォーム（HTMLの .form-wrapper を再現） */}
            <View style={styles.formWrapper}>
              
              {/* メールアドレス（必須） */}
              <View style={styles.formGroup}>
                <Text style={styles.label}>メールアドレス <Text style={styles.required}>必須</Text></Text>
                <TextInput
                  style={styles.input}
                  value={email}
                  onChangeText={setEmail}
                  placeholder="例: user@example.com"
                  keyboardType="email-address"
                  autoCapitalize="none"
                />
              </View>

              {/* パスワード */}
              <View style={styles.formGrid}>
                <View style={[styles.formGroup, { flex: 1, marginRight: 5 }]}>
                  <Text style={styles.label}>パスワード <Text style={styles.required}>必須</Text></Text>
                  <View style={styles.passwordWrapper}>
                    <TextInput
                      style={styles.input}
                      value={password}
                      onChangeText={setPassword}
                      placeholder="8文字以上"
                      secureTextEntry={!isPasswordVisible}
                    />
                    <TouchableOpacity
                      style={styles.toggleEye}
                      onPress={() => setIsPasswordVisible(!isPasswordVisible)}
                    >
                      <Text>{isPasswordVisible ? "👁️" : "🙈"}</Text>
                    </TouchableOpacity>
                  </View>
                </View>

                <View style={[styles.formGroup, { flex: 1, marginLeft: 5 }]}>
                  <Text style={styles.label}>確認用 <Text style={styles.required}>必須</Text></Text>
                  <View style={styles.passwordWrapper}>
                    <TextInput
                      style={styles.input}
                      value={rePassword}
                      onChangeText={setRePassword}
                      placeholder="再入力"
                      secureTextEntry={!isRePasswordVisible}
                    />
                    <TouchableOpacity
                      style={styles.toggleEye}
                      onPress={() => setIsRePasswordVisible(!isRePasswordVisible)}
                    >
                      <Text>{isRePasswordVisible ? "👁️" : "🙈"}</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>

              {/* 性別（Picker） */}
              <View style={styles.formGroup}>
                <Text style={styles.label}>性別 <Text style={styles.required}>必須</Text></Text>
                <View style={styles.pickerContainer}>
                  <Picker
                    selectedValue={gender}
                    onValueChange={(itemValue) => setGender(itemValue)}
                    style={styles.picker}
                  >
                    <Picker.Item label="選択してください" value="" />
                    <Picker.Item label="男性" value="male" />
                    <Picker.Item label="女性" value="female" />
                    <Picker.Item label="その他" value="other" />
                  </Picker>
                </View>
              </View>

              {/* 生年月日 */}
              <View style={styles.formGroup}>
                <Text style={styles.label}>生年月日 <Text style={styles.required}>必須</Text></Text>
                <TextInput
                  style={styles.input}
                  value={birthdate}
                  onChangeText={setBirthdate}
                  placeholder="例: 2000-01-01"
                  keyboardType="numbers-and-punctuation"
                />
              </View>

              {/* 身長・体重 */}
              <View style={styles.formGrid}>
                <View style={[styles.formGroup, { flex: 1, marginRight: 5 }]}>
                  <Text style={styles.label}>身長 (cm)</Text>
                  <TextInput
                    style={styles.input}
                    value={height}
                    onChangeText={setHeight}
                    placeholder="例: 170.5"
                    keyboardType="numeric"
                  />
                </View>

                <View style={[styles.formGroup, { flex: 1, marginLeft: 5 }]}>
                  <Text style={styles.label}>体重 (kg)</Text>
                  <TextInput
                    style={styles.input}
                    value={weight}
                    onChangeText={setWeight}
                    placeholder="例: 65.2"
                    keyboardType="numeric"
                  />
                </View>
              </View>

              {/* ウェアラブル機器 */}
              <View style={styles.formGroup}>
                <Text style={styles.label}>ウェアラブル機器</Text>
                <View style={styles.pickerContainer}>
                  <Picker
                    selectedValue={device}
                    onValueChange={(itemValue) => setDevice(itemValue)}
                    style={styles.picker}
                  >
                    <Picker.Item label="機器を選択してください" value="" />
                    <Picker.Item label="Fitbit" value="fitbit" />
                    <Picker.Item label="Apple Watch" value="apple_watch" />
                    <Picker.Item label="Garmin" value="garmin" />
                  </Picker>
                </View>
              </View>

              {/* 登録ボタン */}
              <TouchableOpacity
                style={[styles.submitButton, loading && styles.disabledButton]}
                onPress={handleRegister}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator color="white" />
                ) : (
                  <Text style={styles.submitButtonText}>登録</Text>
                )}
              </TouchableOpacity>

            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

export default RegisterScreen;

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#f5f6fa' }, // HTMLのbody背景色
  scrollContainer: { paddingVertical: 20 },
  container: { flex: 1, alignItems: 'center', paddingHorizontal: 20 },
  
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 20,
    textAlign: 'center',
  },

  // タブボタンのスタイル
  buttonGroup: {
    flexDirection: 'row',
    width: '100%',
    maxWidth: 400,
    marginBottom: 20,
  },
  tabButton: {
    flex: 1,
    paddingVertical: 12,
    borderWidth: 2,
    borderColor: '#007bff',
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
  },
  tabButtonLeft: { borderTopLeftRadius: 8, borderBottomLeftRadius: 8, marginRight: -2 },
  tabButtonRight: { borderTopRightRadius: 8, borderBottomRightRadius: 8 },
  tabButtonActive: { backgroundColor: '#007bff', borderColor: '#007bff' },
  tabButtonText: { color: '#007bff', fontSize: 16, fontWeight: 'bold' },
  tabButtonTextActive: { color: 'white' },

  // フォーム部分（HTMLの .form-wrapper を再現）
  formWrapper: {
    width: '100%',
    maxWidth: 400,
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 20,
    // HTMLの box-shadow
    ...Platform.select({
      ios: { shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 6 },
      android: { elevation: 4 },
    }),
  },
  formGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  formGroup: {
    marginBottom: 15,
  },
  label: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },
  required: {
    color: '#dc3545', // HTMLの .required color
    fontSize: 12,
    marginLeft: 5,
  },
  input: {
    width: '100%',
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 6,
    padding: 10,
    fontSize: 14,
    backgroundColor: '#fff',
    height: 45,
  },
  passwordWrapper: {
    position: 'relative',
    justifyContent: 'center',
  },
  toggleEye: {
    position: 'absolute',
    right: 12,
    padding: 5,
  },
  
  // Picker用のスタイル
  pickerContainer: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 6,
    backgroundColor: '#fff',
    height: 45,
    justifyContent: 'center',
  },
  picker: {
    width: '100%',
    height: 45, // Pickerの高さを確保
  },

  // 登録ボタン（HTMLの .submit-button）
  submitButton: {
    width: '100%',
    padding: 12,
    marginTop: 20,
    borderRadius: 6,
    backgroundColor: '#007bff',
    alignItems: 'center',
  },
  disabledButton: {
    backgroundColor: '#8bbfe8',
  },
  submitButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
});