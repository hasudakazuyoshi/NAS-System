import React, { useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View
} from 'react-native';

// ★APIサービスの読み込み（app直下なら '../' でOK）
// @ts-ignore
import { apiCall } from '../api/apiService';

export default function ProvisionalRegistrationCompleteScreen(): React.JSX.Element {
  const [isLoading, setIsLoading] = useState(false);

  // 再送信処理
  const handleResend = async (): Promise<void> => {
    setIsLoading(true);

    try {
      // サーバーに再送信リクエストを送る
      // (エンドポイントや引数はサーバーの仕様に合わせて調整してください)
      await apiCall('/auth/resend-activation/', 'POST', {
        email: 'user-example@mail.com', // 実際は前の画面から受け取ったメアドを使います
      }, false);

      Alert.alert("確認", "確認メールを再送信しました");

    } catch (error: any) {
      console.error("再送信エラー:", error);
      Alert.alert("失敗", error.message || "送信できませんでした。");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.body}>
      <View style={styles.container}>
        
        {/* HTMLの .message-container に対応 */}
        <View style={styles.messageContainer}>
          {/* HTMLの .main-message */}
          <Text style={styles.mainMessage}>仮登録が完了しました</Text>
          
          {/* HTMLの .sub-message */}
          <Text style={styles.subMessage}>
            メールアプリを開き本人確認を{'\n'}
            行ってください
          </Text>
        </View>

        {/* HTMLの .resend-link (再送信リンク) */}
        <TouchableOpacity 
          onPress={handleResend}
          disabled={isLoading}
          style={{ opacity: isLoading ? 0.5 : 1 }}
        >
          {isLoading ? (
            <ActivityIndicator size="small" color="#007bff" />
          ) : (
            <Text style={styles.resendLink}>再送信</Text>
          )}
        </TouchableOpacity>

      </View>
    </SafeAreaView>
  );
}

// HTMLのCSSをReact NativeのStyleSheetに変換しました
const styles = StyleSheet.create({
  body: {
    flex: 1,
    backgroundColor: '#FEF3EC', // HTMLの body background-color
    justifyContent: 'center',
    alignItems: 'center',
  },
  container: {
    width: '100%',
    padding: 20,
    alignItems: 'center',
  },
  messageContainer: {
    marginBottom: 50, // HTMLの .message-container margin-bottom: 50px
    alignItems: 'center',
  },
  mainMessage: {
    fontSize: 28, // HTMLの .main-message font-size: 28px
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 15,
    textAlign: 'center',
    lineHeight: 40, // 読みやすく調整
  },
  subMessage: {
    fontSize: 20, // HTMLの .sub-message font-size: 20px
    color: '#555',
    textAlign: 'center',
    lineHeight: 34, // 行間を少し広めに
  },
  resendLink: {
    fontSize: 18, // HTMLの .resend-link font-size: 18px
    color: '#007bff',
    textDecorationLine: 'underline',
  },
});