import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View
} from 'react-native';

// ★修正済み：点を1つ減らして「../」にしました！
// @ts-ignore
import { apiCall } from '../api/apiService';

export default function MailSendScreen(): React.JSX.Element {
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(false);

  // "OK"ボタンを押した時の処理
  const handleOkPress = (): void => {
    // ログイン画面へ戻る (フォルダ構成に合わせてパスは調整してください)
    // 一般的には '/login' や '/(auth)/login' など
    if (router.canGoBack()) {
      router.back();
    } else {
      router.replace('/'); // トップに戻る
    }
  };

  // ★API通信機能（再送信）★
  const handleResend = async (): Promise<void> => {
    setIsLoading(true);

    try {
      // ★変更点2: apiCallを使ってシンプルに送信！
      // 第1引数: エンドポイント ('/resend-email/')
      // 第2引数: メソッド ('POST')
      // 第3引数: データ ({ email: ... })
      // 第4引数: 認証が必要か (false = ログイン前なので不要)
      
      await apiCall('/resend-email/', 'POST', {
        email: 'user-example@mail.com', 
      }, false);

      // 成功したらここに来る
      Alert.alert("成功", "確認メールを再送信しました！");

    } catch (error: any) {
      // 失敗したらここに来る
      console.error("通信エラー:", error);
      Alert.alert("失敗", error.message || "送信できませんでした。");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.body}>
      <View style={styles.container}>
        
        <Text style={styles.h2}>メール送信確認</Text>

        <Text style={styles.messageText}>
          下記メールアドレス宛にパスワードを{'\n'}
          再設定用のURLを送信しました
        </Text>

        <View style={styles.emailDisplay}>
          <Text style={styles.emailText}>
            Email: <Text style={styles.emailBold}>user-example@mail.com</Text>
          </Text>
        </View>

        <TouchableOpacity style={styles.okButton} onPress={handleOkPress}>
          <Text style={styles.okButtonText}>OK</Text>
        </TouchableOpacity>

        {/* 再送信リンク */}
        <TouchableOpacity 
          onPress={handleResend} 
          disabled={isLoading} 
          style={{ opacity: isLoading ? 0.5 : 1 }}
        >
          {isLoading ? (
            <ActivityIndicator size="small" color="#007bff" />
          ) : (
            <Text style={styles.resendLink}>再送信</Text>
          )}
        </TouchableOpacity>

      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  body: {
    flex: 1,
    backgroundColor: '#FEF1E7',
    justifyContent: 'center',
    alignItems: 'center',
  },
  container: {
    width: '100%',
    maxWidth: 400,
    padding: 30,
    alignItems: 'center',
  },
  h2: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#555',
    marginTop: 0,
    marginBottom: 30,
  },
  messageText: {
    fontSize: 16,
    color: '#333',
    lineHeight: 24,
    textAlign: 'left',
    marginBottom: 30,
    width: '100%',
  },
  emailDisplay: {
    width: '100%',
    borderBottomWidth: 1,
    borderBottomColor: '#555',
    paddingBottom: 5,
    marginBottom: 40,
  },
  emailText: {
    fontSize: 16,
    color: '#333',
    textAlign: 'left',
  },
  emailBold: {
    fontWeight: 'bold',
  },
  okButton: {
    paddingVertical: 12,
    paddingHorizontal: 50,
    backgroundColor: '#e0e0e0',
    borderWidth: 2,
    borderColor: '#aaa',
    borderRadius: 4,
    marginBottom: 25,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1.41,
    elevation: 2,
  },
  okButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
  },
  resendLink: {
    fontSize: 16,
    color: '#007bff',
    textDecorationLine: 'underline',
  },
});